import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  Package, 
  ShoppingCart, 
  Users, 
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import api from '../../lib/api';
import { formatCurrency, cn } from '../../lib/utils';

export default function Dashboard() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { data } = await api.get('/dashboard-stats');
      setStats(data);
    } catch (error) {
      console.error('Failed to load stats');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading Dashboard...</div>;

  const cards = [
    { name: 'Total Revenue', value: formatCurrency(stats.totalSales), icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50', trend: '+12%', up: true },
    { name: 'Inventory Items', value: stats.inventoryStats.length, icon: Package, color: 'text-blue-600', bg: 'bg-blue-50', trend: '-2%', up: false },
    { name: 'Total Orders', value: stats.orderCount, icon: ShoppingCart, color: 'text-orange-600', bg: 'bg-orange-50', trend: '+8%', up: true },
    { name: 'Active Users', value: stats.userCount, icon: Users, color: 'text-purple-600', bg: 'bg-purple-50', trend: '+1%', up: true },
  ];

  return (
    <div className="space-y-8 pb-12">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Dashboard Overview</h1>
          <p className="text-gray-500">Welcome back! Here's what's happening with FreshBasket today.</p>
        </div>
        <div className="text-sm font-medium text-gray-400">Last updated: {new Date().toLocaleTimeString()}</div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, idx) => (
          <motion.div
            key={card.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all"
          >
            <div className="flex justify-between items-start mb-4">
              <div className={cn("p-3 rounded-xl", card.bg)}>
                <card.icon className={cn("w-6 h-6", card.color)} />
              </div>
              <div className={cn("flex items-center text-xs font-bold", card.up ? "text-emerald-600" : "text-red-500")}>
                {card.trend} {card.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
              </div>
            </div>
            <p className="text-sm font-medium text-gray-500 mb-1">{card.name}</p>
            <h3 className="text-2xl font-bold text-gray-900">{card.value}</h3>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sales Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="font-serif font-bold text-lg mb-6 flex items-center justify-between">
            Revenue Performance
            <select className="text-xs bg-gray-50 border-none rounded-lg p-2 font-semibold text-gray-500">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </h3>
          <div className="h-[300px]">
             <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={[
                 { name: 'Mon', value: 400 },
                 { name: 'Tue', value: 300 },
                 { name: 'Wed', value: 900 },
                 { name: 'Thu', value: 600 },
                 { name: 'Fri', value: 1200 },
                 { name: 'Sat', value: 1500 },
                 { name: 'Sun', value: 1100 },
               ]}>
                 <defs>
                   <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                     <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                   </linearGradient>
                 </defs>
                 <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                 <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                 <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                 <Tooltip />
                 <Area type="monotone" dataKey="value" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
               </AreaChart>
             </ResponsiveContainer>
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="font-serif font-bold text-lg mb-6 flex items-center gap-2">
            <AlertTriangle className="text-orange-500 w-5 h-5" /> Low Stock Alerts
          </h3>
          <div className="space-y-4">
            {stats.inventoryStats.filter((p: any) => p.stock <= p.reorderLevel).map((p: any) => (
              <div key={p.id} className="flex items-center gap-4 bg-orange-50/50 p-3 rounded-xl border border-orange-100">
                <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-orange-600 font-bold border border-orange-200">
                  {p.stock}
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-bold text-gray-900">{p.title}</h4>
                  <p className="text-xs text-gray-500">Reorder at: {p.reorderLevel}</p>
                </div>
              </div>
            ))}
            {stats.inventoryStats.filter((p: any) => p.stock <= p.reorderLevel).length === 0 && (
              <p className="text-center text-sm text-gray-400 py-8">All stock levels are healthy.</p>
            )}
          </div>
        </div>
      </div>

      {/* Recent Orders Table */}
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-serif font-bold text-lg">Recent Sales Orders</h3>
          <button className="text-emerald-600 text-sm font-bold hover:underline">View All Orders</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-xs font-bold text-gray-400 uppercase tracking-widest border-b border-gray-50">
                <th className="pb-4">Order ID</th>
                <th className="pb-4">Customer</th>
                <th className="pb-4">Date</th>
                <th className="pb-4">Total</th>
                <th className="pb-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {stats.recentOrders.map((order: any) => (
                <tr key={order.id} className="group hover:bg-gray-50/50 transition-colors">
                  <td className="py-4 font-mono text-sm font-semibold">{order.id}</td>
                  <td className="py-4 font-medium">{order.customerName}</td>
                  <td className="py-4 text-sm text-gray-500">{new Date(order.createdAt).toLocaleDateString()}</td>
                  <td className="py-4 font-bold">{formatCurrency(order.totalPrice)}</td>
                  <td className="py-4">
                    <span className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                      order.status === 'completed' ? "bg-emerald-50 text-emerald-600" : "bg-orange-50 text-orange-600"
                    )}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}


