import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ShoppingCart, 
  Search, 
  FileText, 
  Download, 
  MoreHorizontal,
  Clock,
  CheckCircle2,
  Package
} from 'lucide-react';
import { toast } from 'react-toastify';
import api from '../../lib/api';
import { formatCurrency, cn } from '../../lib/utils';
import jsPDF from 'jspdf';

interface Order {
  id: string;
  customerName: string;
  totalPrice: number;
  status: string;
  createdAt: string;
  items: any[];
}

export default function OrderManagement() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const { data } = await api.get('/sales-orders');
      setOrders(data);
    } catch (error) {
      toast.error('Failed to load orders');
    } finally {
      setLoading(false);
    }
  };

  const generateInvoice = (order: Order) => {
    const doc = new jsPDF();
    
    doc.setFontSize(20);
    doc.text('FRESHBASKET INVOICE', 105, 20, { align: 'center' });
    
    doc.setFontSize(12);
    doc.text(`Order ID: ${order.id}`, 20, 40);
    doc.text(`Customer: ${order.customerName}`, 20, 50);
    doc.text(`Date: ${new Date(order.createdAt).toLocaleDateString()}`, 20, 60);
    
    doc.line(20, 70, 190, 70);
    doc.text('Item', 20, 80);
    doc.text('Qty', 140, 80);
    doc.text('Price', 170, 80);
    doc.line(20, 85, 190, 85);
    
    let y = 95;
    order.items.forEach((item: any) => {
      doc.text(item.title, 20, y);
      doc.text(item.quantity.toString(), 140, y);
      doc.text(formatCurrency(item.price * item.quantity), 170, y);
      y += 10;
    });
    
    doc.line(20, y, 190, y);
    doc.setFontSize(14);
    doc.text(`Total: ${formatCurrency(order.totalPrice)}`, 170, y + 10, { align: 'right' });
    
    doc.save(`Invoice-${order.id}.pdf`);
    toast.success('Invoice exported as PDF');
  };

  const filteredOrders = orders.filter(o => 
    o.id.toLowerCase().includes(search.toLowerCase()) ||
    o.customerName.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-serif font-bold text-gray-900">Sales Orders</h1>
        <p className="text-gray-500">Track and manage customer orders and generate invoices.</p>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-gray-100 flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input 
            type="text" 
            placeholder="Search orders by ID or customer..."
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-emerald-500/20 text-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50/50">
              <tr className="text-xs font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100">
                <th className="px-6 py-4">Order ID</th>
                <th className="px-6 py-4">Customer</th>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Amount</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                <tr><td colSpan={6} className="py-20 text-center text-gray-400">Loading orders...</td></tr>
              ) : filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-20 text-center text-gray-400">
                    <ShoppingCart className="w-12 h-12 mx-auto mb-2 opacity-10" />
                    No orders found.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50/30 transition-colors">
                    <td className="px-6 py-4 font-mono font-bold text-sm text-emerald-800">{order.id}</td>
                    <td className="px-6 py-4 font-medium">{order.customerName}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{new Date(order.createdAt).toLocaleDateString()}</td>
                    <td className="px-6 py-4 font-bold">{formatCurrency(order.totalPrice)}</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider w-fit",
                        order.status === 'completed' ? "bg-emerald-50 text-emerald-600" : "bg-blue-50 text-blue-600"
                      )}>
                        {order.status === 'completed' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => generateInvoice(order)}
                        className="p-2 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all flex items-center gap-2 ml-auto text-xs font-bold"
                      >
                        <Download className="w-4 h-4" /> Invoice
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
