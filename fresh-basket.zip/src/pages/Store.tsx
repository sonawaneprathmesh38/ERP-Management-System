import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, Plus, Minus, CreditCard, Search, ArrowRight, ShoppingBag } from 'lucide-react';
import { toast } from 'react-toastify';
import api from '../lib/api';
import { formatCurrency } from '../lib/utils';

interface Product {
  id: string;
  title: string;
  price: number;
  category: string;
  stock: number;
  image?: string;
}

interface CartItem extends Product {
  quantity: number;
}

export default function Store() {
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [showCart, setShowCart] = useState(false);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data } = await api.get('/products');
      setProducts(data);
    } catch (error) {
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const addToCart = (product: Product) => {
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
      if (existing.quantity >= product.stock) {
        toast.warn('Not enough stock!');
        return;
      }
      setCart(cart.map(item => 
        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
    toast.success(`${product.title} added to cart`);
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(cart.map(item => {
      if (item.id === id) {
        const newQty = Math.max(0, item.quantity + delta);
        if (newQty > item.stock) {
          toast.warn('Not enough stock!');
          return item;
        }
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const handleCheckout = async () => {
    try {
      await api.post('/sales-orders', {
        items: cart,
        totalPrice: total,
        status: 'pending',
        customerName: 'Guest Customer'
      });
      toast.success('Order placed successfully!');
      setCart([]);
      setShowCart(false);
    } catch (error) {
      toast.error('Order failed');
    }
  };

  const filteredProducts = products.filter(p => 
    p.title.toLowerCase().includes(search.toLowerCase()) ||
    p.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="relative h-64 rounded-3xl overflow-hidden mb-12">
        <img 
          src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=1200" 
          className="absolute inset-0 w-full h-full object-cover"
          alt="Grocery stores"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex flex-col justify-center p-12 text-white">
          <h1 className="text-4xl font-serif font-bold mb-2">Fresh Groceries</h1>
          <p className="text-lg opacity-90 max-w-md">Get high-quality, local produce delivered right to your doorstep.</p>
        </div>
      </section>

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-white p-4 rounded-3xl border border-gray-200 mb-8 shadow-sm">
        <div className="relative flex-1 w-full max-w-xl">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input 
            type="text" 
            placeholder="Search groceries..."
            className="w-full pl-12 pr-4 py-3 bg-gray-100 border-none rounded-xl focus:ring-1 focus:ring-emerald-600 text-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setShowCart(true)}
          className="relative bg-white border border-gray-200 text-emerald-600 px-6 py-3 rounded-xl font-semibold flex items-center gap-2 hover:bg-gray-100 transition-all shrink-0"
        >
          <ShoppingCart className="w-5 h-5" />
          <span>Basket ({cart.length})</span>
          {cart.length > 0 && (
            <span className="absolute -top-2 -right-2 bg-emerald-600 text-white w-6 h-6 rounded-full text-xs flex items-center justify-center font-bold border-2 border-white">
              {cart.reduce((a, b) => a + b.quantity, 0)}
            </span>
          )}
        </button>
      </div>

      {/* Product Grid */}
      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[1,2,3,4].map(n => <div key={n} className="h-64 bg-gray-200 animate-pulse rounded-2xl" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {filteredProducts.map((product) => (
            <motion.div 
              key={product.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white p-5 rounded-3xl border border-transparent hover:border-gray-300 transition-colors shadow-sm flex flex-col group relative overflow-hidden"
            >
              {product.stock <= product.reorderLevel && (
                <div className="absolute top-0 right-0 bg-[#D4A373] text-white px-3 py-1 text-[10px] font-bold uppercase rounded-bl-xl z-10">Running Low</div>
              )}
              <div className="aspect-square bg-gray-100 rounded-2xl mb-4 flex items-center justify-center text-emerald-600 overflow-hidden">
                {product.image ? (
                  <img src={product.image} alt={product.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                ) : (
                  <ShoppingBag className="w-12 h-12 opacity-30 group-hover:scale-110 transition-transform" />
                )}
              </div>
              <p className="text-xs font-semibold text-gray-400 mb-1 uppercase tracking-wider">{product.category}</p>
              <h3 className="font-bold text-gray-700 mb-1 line-clamp-1">{product.title}</h3>
              <p className="text-lg font-bold text-emerald-600 mb-4">{formatCurrency(product.price)}</p>
              
              <button 
                onClick={() => addToCart(product)}
                className="mt-auto w-full py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-bold text-gray-700 hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-colors"
                disabled={product.stock === 0}
              >
                {product.stock === 0 ? 'Out of Stock' : 'Add to Basket'}
              </button>
            </motion.div>
          ))}
        </div>
      )}

      {/* Cart Drawer Overlay */}
      <AnimatePresence>
        {showCart && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCart(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white z-[70] shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h2 className="text-xl font-serif font-bold text-gray-700 flex items-center gap-2">
                  <ShoppingCart className="text-emerald-600" /> Your Order
                </h2>
                <button onClick={() => setShowCart(false)} className="p-2 hover:bg-gray-100 rounded-full">
                   <ArrowRight className="text-gray-400" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {cart.length === 0 ? (
                  <div className="text-center py-12">
                    <ShoppingBag className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                    <p className="text-gray-500">Your basket is empty.</p>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div key={item.id} className="flex gap-4 items-center bg-gray-50 p-3 rounded-2xl">
                      <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center text-emerald-600 shrink-0 overflow-hidden border border-gray-100 p-0">
                        {item.image ? (
                          <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                        ) : (
                          <ShoppingBag className="w-8 h-8 opacity-20" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-sm">{item.title}</h4>
                        <p className="text-xs text-gray-500">{formatCurrency(item.price)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:bg-gray-200 rounded-lg"><Minus className="w-4 h-4" /></button>
                        <span className="font-bold w-6 text-center">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:bg-gray-200 rounded-lg"><Plus className="w-4 h-4" /></button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="p-6 border-t border-gray-200 bg-white">
                <div className="flex justify-between items-center mb-6">
                  <span className="text-gray-500 text-sm">Subtotal</span>
                  <span className="text-xl font-bold text-gray-700">{formatCurrency(total)}</span>
                </div>
                <button 
                  onClick={handleCheckout}
                  disabled={cart.length === 0}
                  className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-emerald-700 shadow-lg shadow-emerald-600/20 transition-all disabled:opacity-50"
                >
                  <CreditCard className="w-5 h-5" /> 
                  Order Now
                </button>
                <p className="text-center text-[10px] text-gray-400 mt-4 uppercase tracking-widest font-bold">Secure Organic Payments</p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
