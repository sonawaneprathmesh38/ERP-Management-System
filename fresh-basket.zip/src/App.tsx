/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, createContext, useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { LayoutDashboard, ShoppingCart, Box, Users, Settings, LogOut, Menu, X, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import api from './lib/api';

// Pages
import Store from './pages/Store';
import Dashboard from './pages/erp/Dashboard';
import ProductManagement from './pages/erp/Products';
import OrderManagement from './pages/erp/Orders';
import UserManagement from './pages/erp/Users';
import Login from './pages/Login';
import Register from './pages/Register';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'sales' | 'purchase' | 'inventory';
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (token: string, user: User) => void;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

const ProtectedRoute = ({ children, roles }: { children: React.ReactNode, roles?: string[] }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>;
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />;

  return <>{children}</>;
};

const Navigation = () => {
  const { user, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const isERP = location.pathname.startsWith('/erp') || location.pathname === '/dashboard';

  const erpLinks = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Products', path: '/erp/products', icon: Box },
    { name: 'Sales Orders', path: '/erp/orders', icon: ShoppingCart },
    { name: 'Users', path: '/erp/users', icon: Users, role: 'admin' },
  ];

  return (
    <>
      {/* Topbar */}
      <nav className="fixed top-0 left-0 right-0 h-20 bg-white border-b border-gray-200 z-50 flex items-center justify-between px-6 md:px-10">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center">
            <ShoppingBag className="w-5 h-5 text-white" />
          </div>
          <span className="text-2xl font-serif font-bold tracking-tight text-gray-700">FreshBasket</span>
        </Link>

        <div className="flex items-center gap-4">
          <Link to="/" className="text-sm font-medium hover:text-emerald-600">Store</Link>
          {user ? (
            <div className="flex items-center gap-4">
              <Link to="/dashboard" className="text-sm font-medium hover:text-emerald-600">ERP</Link>
              <div className="flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold">
                {user.role.toUpperCase()}
              </div>
              <button onClick={logout} className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <Link to="/login" className="bg-emerald-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-emerald-700">
              Login
            </Link>
          )}
          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </nav>

      {/* Sidebar for ERP */}
      {user && isERP && (
        <aside className="fixed left-0 top-20 bottom-0 w-64 bg-gray-100 border-r border-gray-200 hidden md:flex flex-col gap-8 overflow-y-auto">
          <div className="p-4 space-y-2">
            {erpLinks.map((link) => {
              if (link.role && link.role !== user.role) return null;
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                    isActive ? "bg-emerald-50 text-emerald-700 font-semibold" : "text-gray-600 hover:bg-gray-50"
                  )}
                >
                  <link.icon className={cn("w-5 h-5", isActive ? "text-emerald-600" : "text-gray-400")} />
                  <span>{link.name}</span>
                </Link>
              );
            })}
          </div>
        </aside>
      )}
    </>
  );
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedToken = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = (newToken: string, newUser: User) => {
    setToken(newToken);
    setUser(newUser);
    localStorage.setItem('token', newToken);
    localStorage.setItem('user', JSON.stringify(newUser));
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, loading }}>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Navigation />
          <main className={cn("pt-20", user && "md:pl-64")}>
            <div className="max-w-7xl mx-auto p-4 md:p-8">
              <AnimatePresence mode="wait">
                <Routes>
                  <Route path="/" element={<Store />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/register" element={<Register />} />
                  
                  {/* ERP Routes */}
                  <Route path="/dashboard" element={
                    <ProtectedRoute>
                      <Dashboard />
                    </ProtectedRoute>
                  } />
                  <Route path="/erp/products" element={
                    <ProtectedRoute>
                      <ProductManagement />
                    </ProtectedRoute>
                  } />
                  <Route path="/erp/orders" element={
                    <ProtectedRoute>
                      <OrderManagement />
                    </ProtectedRoute>
                  } />
                  <Route path="/erp/users" element={
                    <ProtectedRoute roles={['admin']}>
                      <UserManagement />
                    </ProtectedRoute>
                  } />
                  {/* More routes can be added here */}
                </Routes>
              </AnimatePresence>
            </div>
          </main>
          <ToastContainer position="bottom-right" />
        </div>
      </Router>
    </AuthContext.Provider>
  );
}

